import React from "react"

const Recipe = ({title, calories, image, ingredients, label}) => {
    return(
        <div>
            <h1>{title}</h1>
            <p>{calories}</p>
            <img src={image} alt=""></img>
            <ol>
                {ingredients.map(ingredient =>(
                    <li>{ingredient.text}</li>
                ))}
            </ol>
            <p>{label}</p>
        </div>
    )
}
export default Recipe

